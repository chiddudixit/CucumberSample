package java_selenium;

//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class css {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		
		System.setProperty("webdriver.chrome.driver", s);
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("http://www.demoaut.com/");
		
		//List<WebElement> allRows = driver.findElements(By.tagName("tr"));
		//int noOfRows = allRows.size();
		//System.out.println(noOfRows);
		
		//List<WebElement> allImages = driver.findElements(By.tagName("img"));
		//int noOfImg = allImages.size();
		//System.out.println(noOfImg);
		
		driver.findElement(By.cssSelector("input[name=\"userName\"]")).sendKeys("mercury");
		driver.findElement(By.cssSelector("input[name=\"password\"]")).sendKeys("mercury");
		driver.findElement(By.cssSelector("input[name=\"login\"]")).click();
		Thread.sleep(10000);
		driver.findElement(By.cssSelector("a[href='mercurywelcome.php']")).click();


	}

}
