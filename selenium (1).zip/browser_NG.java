package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class browser_NG {
		String baseurl = "http://newtours.demoaut.com/";
		String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		public WebDriver driver;
		
		 @BeforeClass
		  public void openBrowser() {
			  System.setProperty("webdriver.chrome.driver", s);
			  driver = new ChromeDriver();
			  driver.get(baseurl);
			  
		  }
		  
		   @AfterClass
		   public void closeBrowser()
		   {
			 driver.close();
		   }
	
  @Test
  public void verifyHomepage() 
  {
	  
	  String expectedTitle = "Under Construction: Mercury Tours";
	  String actualTitle = driver.getTitle();
	  Assert.assertEquals(actualTitle, expectedTitle);
	  System.out.println("Inside verifyHomepagetitle");
  }
  
  @Test
  public void register()
  {
	  driver.findElement(By.linkText("REGISTER")).click();
	  String expectedTitle = "Register: Mercury Tours";
	  String actualTitle = driver.getTitle();
	  Assert.assertEquals(actualTitle, expectedTitle);
	  System.out.println("Register page..");
  }
   @Test
   public void support()
   {
	      driver.findElement(By.linkText("SUPPORT")).click();
		  String expectedTitle = "Under Construction: Mercury Tours";
		  String actualTitle = driver.getTitle();
		  Assert.assertEquals(actualTitle, expectedTitle);
		  System.out.println("support page..");
   }
   
   @Test
   public void contact()
   {
	      driver.findElement(By.linkText("CONTACT")).click();
		  String expectedTitle = "Under Construction: Mercury Tours";
		  String actualTitle = driver.getTitle();
		  Assert.assertEquals(actualTitle, expectedTitle);
		  System.out.println("Contact page..");
   }
}
