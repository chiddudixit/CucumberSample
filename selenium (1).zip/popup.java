package TestNG;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class popup {
		@Test
    public void f() {
	  String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",s);
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/V4/");
		driver.findElement(By.name("uid")).sendKeys("shalini");
		driver.findElement(By.name("password")).sendKeys("shalini");
		driver.findElement(By.name("btnLogin")).submit();
		
		Alert alert=driver.switchTo().alert();
		
		String alertMessage=driver.switchTo().alert().getText();
		
		System.out.println(alertMessage);
		
		alert.accept();
  }
}
