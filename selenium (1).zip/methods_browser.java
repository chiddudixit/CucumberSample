package java_selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class methods_browser {
	public static WebDriver getDriver(String browserName)
	{
	if(browserName.equals("ie"))
	{
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\IEDriverServer\\IEDriverServer.exe";
		
		System.setProperty("webdriver.ie.driver", s);
		
		return new InternetExplorerDriver();
	}
	
	else if(browserName.equals("chrome"))
	{
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		
		System.setProperty("webdriver.chrome.driver", s);
		
		return new ChromeDriver();
	}
	else
	{
		return null;
	}

}

}

