package java_selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class fire_fox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\geckodriver-v0.24.0-win64\\geckodriver.exe";
		
		System.setProperty("webdriver.gecko.driver", s);
		
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://google.com");
	}

}
