package java_selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class navigate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		
		System.setProperty("webdriver.chrome.driver", s);
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("http://www.demoaut.com/");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("REGISTER")).click();
		
		driver.navigate().back();
		
		driver.navigate().forward();
		
		driver.navigate().to("http://google.com");
		
		driver.navigate().refresh();
		
		String text=driver.getTitle();
		System.out.println(text);
		
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
	}

}
