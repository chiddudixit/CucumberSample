package maven_book;

import org.testng.annotations.Test;

public class maven_WB {
  @Test
  public void f() {
  }
}
