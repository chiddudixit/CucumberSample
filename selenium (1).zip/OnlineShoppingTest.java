package case_study;

import org.testng.annotations.Test;

public class OnlineShoppingTest {
  @Test
  public void testRegistration() {
	  
  }
  @Test
  public void testCart()
  {
	  
  }
}
