package TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class action_NG {
  @Test
  public void f() {
	    String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",s);
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http:/demowebshop.tricentis.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions action=new Actions(driver);
		
		action.moveToElement(driver.findElement(By.xpath("//a[@href='/electronics']"))).perform();
		
		action.moveToElement(driver.findElement(By.xpath("//a[@href='/camera-photo']"))).click().build().perform();

  }
}
