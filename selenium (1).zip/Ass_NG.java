package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Ass_NG {
	public String baseurl = "http://newtours.demoaut.com/";
	
	String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
	
	public WebDriver driver;
	
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", s);
	  driver = new ChromeDriver();
	  driver.get(baseurl);
	  
	  String expectedTitle = "Welcome: Mercury Tours";
	  String actualTitle = driver.getTitle();
	Assert.assertEquals(actualTitle, expectedTitle);
	System.out.println("Inside verifyHomepagetitle");
  }
}
