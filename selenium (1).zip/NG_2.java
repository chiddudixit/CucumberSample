package TestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NG_2 {
	
	@BeforeClass
	public void openBrowser()
	{
		System.out.println("Opening Browser");
	}
	
	@AfterClass
	public void closeBrowser()
	{
		System.out.println("Closing Browser");
	}
	
	@BeforeMethod
	public void clickHome()
	   {
		   System.out.println("directing to Home Page"); 
	   }
	
	@AfterMethod
	public void signout()
	{
		System.out.println("Signing out...");
	}
  @Test(priority=1)
  public void a_test() 
  {
	  System.out.println("a");
  }
  
  @Test(priority=4)
  public void b_test()
  {
	  System.out.println("b");
  }
  
  @Test(priority=2)
  public void c_test()
  {
	  System.out.println("c");
  }
}
