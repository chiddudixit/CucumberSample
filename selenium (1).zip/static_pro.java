package TestNG;

import org.testng.annotations.DataProvider;

public class static_pro {
 @DataProvider
 public static Object[][] getData()
 {
	 return new Object[][] {{5,"five"}};
 }
 @DataProvider
 public static Object[][] getData1()
 {
	 return new Object[][] {{6,"six"}};
 }
 
}
