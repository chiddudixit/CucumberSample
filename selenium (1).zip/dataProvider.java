package TestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProvider {
  @Test(dataProvider="dp")
  public void DataInfo(Integer age, String name) {
	  System.out.println("Age is"+" "+age);
	  System.out.println("Name is"+" "+name);
  }
  @DataProvider
  public Object[][] dp()
  {
	  return new Object[][]
			  {
		  new Object[] {25, "prasha"},
		  new Object[] {24, "shalini"},
		  new Object[] {25, "praveen"},

			  };
  }
}
