package TestNG;

import org.testng.annotations.Test;

public class main_static {
  @Test(dataProvider="getData", dataProviderClass=static_pro.class)
  public void client1(Integer a,String b)
  {
	  System.out.println("Client1 testing: Data(" + a +" ,"+"String is"+"-"+b+")");
  }
  
  @Test(dataProvider="getData1", dataProviderClass=static_pro.class)
  public void client2(Integer a,String b)
  {
	  System.out.println("Client1 testing: Data(" + a +" ,"+"String is"+"-"+b+")");
  }
  
}
