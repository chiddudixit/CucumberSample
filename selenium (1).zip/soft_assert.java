package TestNG;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class soft_assert {
  @Test
  public void f() {
	  SoftAssert ss = new SoftAssert();
	  
	  System.out.println("Checking 1st validation");
	  ss.assertEquals(11, 11);
	  
	  System.out.println("Checking 2st validation");
	  ss.assertEquals("Hello", "Helloo");
	  
	 // ss.assertAll();
  }
}
