package java_selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class understand {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		
		System.setProperty("webdriver.chrome.driver", s);
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("http://www.demoaut.com/");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		
		WebElement userfield = driver.findElement(By.name("userName"));
		String userContent = userfield.getAttribute("value");
		userfield.clear();
		
		WebElement pwdfield = driver.findElement(By.name("password"));
		String userpwdContent = pwdfield.getAttribute("value");
		pwdfield.clear();
		
		System.out.println("UserName content is: "+" "+userContent);
		System.out.println("UserPassword content is: "+" "+userpwdContent);
		
		WebElement Signin = driver.findElement(By.name("login"));
		String SigninValue = Signin.getAttribute("value");
		String SigninSRC = Signin.getAttribute("src");
		
		System.out.println("Signin values: "+" "+SigninValue);
		System.out.println("SigninSRC values: "+" "+SigninSRC);
		
	}

}
