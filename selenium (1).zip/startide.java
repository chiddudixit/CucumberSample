package java_selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class startide {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\IEDriverServer.exe";
		
		System.setProperty("webdriver.ie.driver", s);
		
		WebDriver driver = new InternetExplorerDriver();
		
		driver.get("http://google.co.in/");
		
		
	}

}
