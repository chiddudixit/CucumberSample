package TestNG;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class links {
  @Test
  public void f() {
	  String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",s);
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http:/demowebshop.tricentis.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		List <WebElement> linklist = driver.findElements(By.tagName("a"));
		System.out.println("Number of links: "+linklist.size());
		for(WebElement link : linklist)
		
		System.out.println(link.getText() +":-"+ link.getAttribute("href"));
		
  }
}
