package TestNG;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;

public class provider_testme {
	public String path="http://10.232.237.143:443/TestMeApp/";
	String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
	WebDriver driver;
	@BeforeClass
	  public void openBrowser() {
		  System.setProperty("webdriver.chrome.driver", s);
		  driver = new ChromeDriver();
		  driver.get(path);
		  
	  }
	  
	   @AfterClass
	   public void closeBrowser()
	   {
		 driver.close();
	   }
	   
	  
	@Test(dataProvider = "dp")
  public void f(String n, String s) {
	  System.out.println("userName is"+" "+n);
	  System.out.println("pwd is"+" "+s);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] {"shalini" , "abc" },
      new Object[] { "prasha", "abc123" },
    };
  }
}
