package TestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NG_1 {
	
   @BeforeClass
  public void openBrowser() {
	  System.out.println("Opening Browser");
  }
  
   @AfterClass
   public void closeBrowser()
   {
	   System.out.println("Closing Browser");
   }
   
   @BeforeMethod
   public void clickHome()
   {
	   System.out.println("directing to Home Page"); 
   }
  
   @AfterMethod
   public void signOut()
   {
	   System.out.println("Signing out....");
   }
   
   @Test
   public void testRegister()
   {
	   System.out.println("Register page....");
   }
   
   @Test
   public void testSupport()
   {
	   System.out.println("Go to support");
   }
   
   @Test
   public void testContact()
   {
	   System.out.println("Contacts...");
   }
}
