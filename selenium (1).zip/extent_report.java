package demo;

import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.record.pivottable.ExtendedPivotTableViewFieldsRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class extent_report {
	WebDriver driver = null;
  @Test
  public void f() {
	  
	  String path="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		 driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get("http://10.232.237.143:443/TestMeApp/"); 
	    
	    driver.manage().window().maximize();
	    driver.findElement(By.linkText("SignIn")).click();
	    driver.findElement(By.name("userName")).sendKeys("lalitha");
		driver.findElement(By.name("password")).sendKeys("password123");
	    driver.findElement(By.name("Login")).click();
	    ExtentHtmlReporter reporter = new ExtentHtmlReporter("C:\\\\Users\\\\Training_b6b.01.09\\\\Desktop\\\\selenium jar\\demo3.html");
	    ExtentReports extent = new ExtentReports();
	    extent.attachReporter(reporter);
	    ExtentTest logger = extent.createTest("Login");
	    logger.log(Status.INFO, "Login into application");
	    logger.log(Status.PASS, "Login Successfully");
	    extent.flush();
  }
}
