package java_selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class chrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		
		System.setProperty("webdriver.chrome.driver", s);
		
		WebDriver driver= new ChromeDriver();
		
		driver.get("https://google.com");
	}

}
