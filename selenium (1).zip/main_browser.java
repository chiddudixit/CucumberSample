package java_selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class main_browser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new methods_browser().getDriver("ie");
		
		driver.get("http://www.demoaut.com/");
		
		driver.findElement(By.linkText("REGISTER")).click();
		driver.findElement(By.name("firstName")).sendKeys("Prasha");
		driver.findElement(By.name("lastName")).sendKeys("shalu");
		driver.findElement(By.name("phone")).sendKeys("9325763945");
		driver.findElement(By.id("userName")).sendKeys("shal@gmail.com");
		driver.findElement(By.name("address1")).sendKeys("nagar");
		driver.findElement(By.name("city")).sendKeys("chennai");
		driver.findElement(By.name("state")).sendKeys("TN");
		driver.findElement(By.name("postalCode")).sendKeys("685498");
		Select select = new Select(driver.findElement(By.name("country")));
				select.selectByVisibleText("INDIA");
		WebElement UName = driver.findElement(By.id("email"));
		UName.sendKeys("shal@gmail.com");
		driver.findElement(By.name("password")).sendKeys("jd67");
		driver.findElement(By.name("confirmPassword")).sendKeys("jd67");
		driver.findElement(By.name("register")).click();
		
		WebElement home = driver.findElement(By.linkText("Home"));
		String text=home.getText();
		System.out.println(text);
		home.click();

	}

}
