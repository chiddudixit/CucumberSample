package TestNG;

import org.testng.annotations.Test;

public class xmlCreation {
  @Test
  public void f() {
  }
}
