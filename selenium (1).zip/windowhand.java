package TestNG;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class windowhand {
  @Test
  public void f() {
	    String s = "C:\\Users\\Training_b6b.01.09\\Desktop\\selenium jar\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",s);
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/popup.php");
		
		driver.findElement(By.xpath("//a[contains(text(),'Click Here')]")).click();
		
		String MainWindow=driver.getWindowHandle();
		 System.out.println("Main window unique no"+MainWindow);
		 
		 Set<String> s1=driver.getWindowHandles();
		 for(String string : s1)
		 {
			 String ChildWindow=string;
			 System.out.println("Child window unique no"+ChildWindow);
			 driver.switchTo().window(ChildWindow);
	 	 }
		 driver.findElement(By.name("emailid")).sendKeys("sha@gmail.com");
		 driver.findElement(By.name("btnLogin")).submit();
		 driver.switchTo().window(MainWindow);
  }
}
